Oppgave A
